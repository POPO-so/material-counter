"""Experimental raw-MJPEG to PL JPEG/RLE/FRG transport.

This module is isolated from the existing board service and RLE runner. It
fails closed: ambiguous DMA ownership holds both CMA buffers until externally
established safe; it never resets a channel or retries implicitly.
"""
from __future__ import annotations

import math
import numbers
import operator
import time
from typing import Any, Iterator

from .protocol import HEIGHT, MAX_RUNS, RX_CAPACITY, WIDTH, decode_packet
from .transport import (
    DDR_BASE, DDR_LIMIT, DMA_HALTED, DMA_IDLE, DMA_STATUS_ERROR_MASK,
    DMA_MM2S_ADDRESS, DMA_MM2S_LENGTH, DMA_MM2S_STATUS,
    DMA_S2MM_ADDRESS, DMA_S2MM_LENGTH, DMA_S2MM_STATUS, RLE_SIGNATURE,
)

JPEG_MAX_BYTES = 512000
JPEG_SIZE = 0x10
JPEG_FRAME_ID = 0x18
JPEG_STATUS = 0x20
JPEG_STATUS_VALID = 0x24
JPEG_AP_CTRL = 0x00
PREVIEW_STATUS = 0x0008
PREVIEW_CAPTURED_ID = 0x0018
PREVIEW_DISPLAYED_ID = 0x001C
PREVIEW_ACCEPT_ID = 0x0020
PREVIEW_MASK_ACCEPT = 0x0024
FRG_SIGNATURE = 0x46524731


def _uint(value: Any, name: str, maximum: int = 0xFFFFFFFF) -> int:
    if isinstance(value, bool) or not isinstance(value, numbers.Integral):
        raise TypeError(f"{name} must be an integer")
    value = int(value)
    if not 0 <= value <= maximum:
        raise ValueError(f"{name} must be in 0..{maximum}")
    return value


def _buffer_span(buffer: Any, size: int, alignment: int, name: str) -> tuple[int, int]:
    try:
        physical = operator.index(buffer.physical_address)
        device = operator.index(buffer.device_address)
        nbytes = operator.index(buffer.nbytes)
    except (AttributeError, TypeError) as exc:
        raise ValueError(f"{name} buffer must expose addresses and nbytes") from exc
    if physical != device:
        raise ValueError(f"{name} physical and device addresses must match")
    if nbytes != size:
        raise ValueError(f"{name} buffer must be exactly {size} bytes")
    if physical < DDR_BASE or physical + size > DDR_LIMIT:
        raise ValueError(f"{name} buffer is outside the admitted DDR range")
    if physical % alignment:
        raise ValueError(f"{name} buffer must be {alignment}-byte aligned")
    return physical, physical + size


def _bytes_view(value: Any) -> memoryview:
    try:
        view = memoryview(value)
        if not view.contiguous:
            raise TypeError
        return view.cast("B")
    except (TypeError, ValueError) as exc:
        raise TypeError("JPEG frame must be contiguous bytes-like data") from exc


def iter_raw_mjpeg(device: Any = 0, *, cv2_module: Any = None,
                   max_consecutive_invalid: int = 3,
                   stats: dict[str, Any] | None = None) -> Iterator[bytes]:
    """Yield complete raw V4L2 MJPG packets, dropping a bounded corrupt streak."""
    if (isinstance(max_consecutive_invalid, bool) or
            not isinstance(max_consecutive_invalid, numbers.Integral) or
            max_consecutive_invalid < 0):
        raise ValueError("max_consecutive_invalid must be a nonnegative integer")
    if stats is None:
        stats = {}
    if not isinstance(stats, dict):
        raise TypeError("stats must be a dict")
    stats.update(valid_packets=0, invalid_packets=0, consecutive_invalid_packets=0,
                 max_consecutive_invalid=int(max_consecutive_invalid),
                 last_invalid_reason=None)
    if cv2_module is None:
        import cv2 as cv2_module
    capture = cv2_module.VideoCapture(device, cv2_module.CAP_V4L2)
    if not capture.isOpened():
        capture.release()
        raise RuntimeError("cannot open V4L2 camera")
    try:
        settings = (
            (cv2_module.CAP_PROP_FOURCC, cv2_module.VideoWriter_fourcc(*"MJPG")),
            (cv2_module.CAP_PROP_FRAME_WIDTH, WIDTH),
            (cv2_module.CAP_PROP_FRAME_HEIGHT, HEIGHT),
            (cv2_module.CAP_PROP_CONVERT_RGB, 0),
        )
        for prop, value in settings:
            if not capture.set(prop, value):
                raise RuntimeError(f"V4L2 camera rejected property {prop}")
        actual_fourcc = int(round(capture.get(cv2_module.CAP_PROP_FOURCC)))
        actual_format = "".join(chr((actual_fourcc >> (8 * byte)) & 0xFF)
                                for byte in range(4))
        actual_width = int(round(capture.get(cv2_module.CAP_PROP_FRAME_WIDTH)))
        actual_height = int(round(capture.get(cv2_module.CAP_PROP_FRAME_HEIGHT)))
        if (actual_format != "MJPG" or actual_width != WIDTH or actual_height != HEIGHT):
            raise RuntimeError(
                f"V4L2 negotiated {actual_format!r} {actual_width}x{actual_height}; "
                f"expected MJPG {WIDTH}x{HEIGHT}"
            )
        consecutive_invalid = 0
        while True:
            ok, encoded = capture.read()
            if not ok:
                return
            payload = None
            invalid_reason = None
            if encoded is None:
                invalid_reason = "empty payload"
            else:
                try:
                    payload = _bytes_view(encoded)
                except (TypeError, ValueError):
                    invalid_reason = "payload is not a contiguous byte stream"
                if (invalid_reason is None and
                        (payload.nbytes < 4 or payload[:2].tobytes() != b"\xff\xd8"
                         or payload[-2:].tobytes() != b"\xff\xd9")):
                    invalid_reason = "incomplete JPEG markers"
            if invalid_reason is not None:
                consecutive_invalid += 1
                stats["invalid_packets"] += 1
                stats["consecutive_invalid_packets"] = consecutive_invalid
                stats["last_invalid_reason"] = invalid_reason
                if consecutive_invalid > max_consecutive_invalid:
                    raise RuntimeError(
                        "V4L2 exceeded the consecutive invalid MJPG packet limit: "
                        f"{consecutive_invalid} ({invalid_reason})")
                continue
            if payload.nbytes > JPEG_MAX_BYTES:
                raise RuntimeError(f"V4L2 JPEG packet exceeds {JPEG_MAX_BYTES} bytes")
            consecutive_invalid = 0
            stats["valid_packets"] += 1
            stats["consecutive_invalid_packets"] = 0
            yield payload.tobytes()
    finally:
        capture.release()


class JpegRleDmaTransport:
    """Transfer compressed JPEG and accept a preview only after all gates pass."""

    def __init__(self, send_channel: Any, recv_channel: Any, dma_regs: Any,
                 rle_control: Any, jpeg_control: Any, preview_control: Any,
                 tx_buffer: Any, rx_buffer: Any, timeout_s: float = 5.0):
        if (isinstance(timeout_s, bool) or not isinstance(timeout_s, numbers.Real)
                or not math.isfinite(timeout_s) or timeout_s <= 0):
            raise ValueError("timeout_s must be a positive finite number")
        self.send_channel, self.recv_channel, self.dma_regs = send_channel, recv_channel, dma_regs
        self.rle_control, self.jpeg_control = rle_control, jpeg_control
        self.preview_control = preview_control
        self.tx_buffer, self.rx_buffer = tx_buffer, rx_buffer
        self.timeout_s = float(timeout_s)
        self.dma_may_be_active = False
        self._closed = False
        self._completed_frames = 0
        self._last_frame_id: int | None = None
        self._pending_frame_id: int | None = None

    def _preflight(self) -> None:
        tx0, tx1 = _buffer_span(self.tx_buffer, JPEG_MAX_BYTES, 8, "TX")
        rx0, rx1 = _buffer_span(self.rx_buffer, RX_CAPACITY, 4, "RX")
        if tx0 < rx1 and rx0 < tx1:
            raise ValueError("TX and RX buffers overlap")
        if RX_CAPACITY > (1 << 19) - 1:
            raise ValueError("RX capacity exceeds the configured 19-bit DMA length")
        if int(self.rle_control.read(0x04)) != RLE_SIGNATURE:
            raise RuntimeError("RLE hardware signature mismatch")
        if int(self.rle_control.read(0x2C)) != (HEIGHT << 16) | WIDTH or int(self.rle_control.read(0x30)) != MAX_RUNS:
            raise RuntimeError("RLE geometry or capacity mismatch")
        rle_state = int(self.rle_control.read(0x08))
        if rle_state & 0x5:
            raise RuntimeError("RLE pipeline is busy or has a latched input error")
        if rle_state & 0x2 and self._completed_frames == 0:
            raise RuntimeError("RLE pipeline reports an unconsumed prior frame")
        jpeg_ctrl = int(self.jpeg_control.read(JPEG_AP_CTRL))
        if not jpeg_ctrl & 0x4:
            raise RuntimeError("JPEG core is not idle")
        if int(self.preview_control.read(0x0200)) != FRG_SIGNATURE:
            raise RuntimeError("FRG signature mismatch")
        channels = ((DMA_MM2S_STATUS, "MM2S", self.send_channel),
                    (DMA_S2MM_STATUS, "S2MM", self.recv_channel))
        for offset, name, channel in channels:
            status = int(self.dma_regs.read(offset))
            if status & DMA_STATUS_ERROR_MASK:
                raise RuntimeError(f"{name} DMA has error bits set")
            if not status & (DMA_IDLE | DMA_HALTED):
                # PYNQ 3.1.1 starts simple-mode channels when the Overlay driver
                # constructs them. Its first transfer is explicitly permitted
                # before DMASR.IDLE is asserted; later transfers still require
                # the completion poll above to prove the channel idle.
                initial_pynq_start = (
                    self._completed_frames == 0 and self._last_frame_id is None and
                    bool(getattr(channel, "_first_transfer", False)) and
                    getattr(channel, "_active_buffer", None) is None and
                    bool(getattr(channel, "running", False)))
                if not initial_pynq_start:
                    raise RuntimeError(f"{name} DMA is not idle")

    def _wait_for_completion(self) -> tuple[int, int]:
        deadline = time.monotonic() + self.timeout_s
        jpeg_valid = False
        jpeg_done = False
        while True:
            mm2s = int(self.dma_regs.read(DMA_MM2S_STATUS))
            s2mm = int(self.dma_regs.read(DMA_S2MM_STATUS))
            if mm2s & DMA_STATUS_ERROR_MASK:
                raise RuntimeError(f"MM2S DMA error: 0x{mm2s:08x}")
            if s2mm & DMA_STATUS_ERROR_MASK:
                raise RuntimeError(f"S2MM DMA error: 0x{s2mm:08x}")
            rle_state = int(self.rle_control.read(0x08))
            jpeg_ctrl = int(self.jpeg_control.read(JPEG_AP_CTRL))
            # AP_CTRL ap_done is clear-on-read; retain the observation while
            # the downstream RLE and DMA stages finish.
            jpeg_done = jpeg_done or bool(jpeg_ctrl & 0x2)
            # status_ap_vld is read-to-clear; do not read the status data until
            # this fresh post-start valid indication has been observed.
            valid = bool(int(self.jpeg_control.read(JPEG_STATUS_VALID)) & 1)
            jpeg_valid = jpeg_valid or valid
            if ((mm2s & DMA_IDLE) and (s2mm & DMA_IDLE) and
                    (rle_state & 0x2) and not (rle_state & 0x5) and
                    jpeg_done and jpeg_valid):
                return int(self.dma_regs.read(DMA_S2MM_LENGTH)), int(self.rle_control.read(0x0C))
            if time.monotonic() >= deadline:
                raise TimeoutError("JPEG/RLE/DMA completion timed out")
            time.sleep(min(0.001, max(0.0001, self.timeout_s / 100)))

    def _wait_preview(self, frame_id: int, dropped_before: int) -> None:
        deadline = time.monotonic() + self.timeout_s
        while True:
            status = int(self.preview_control.read(PREVIEW_STATUS))
            frg_state = int(self.preview_control.read(0x0204))
            frg_id = int(self.preview_control.read(0x0208))
            dropped = int(self.preview_control.read(0x0214))
            captured_id = int(self.preview_control.read(PREVIEW_CAPTURED_ID))
            if dropped != dropped_before:
                raise RuntimeError("FRG dropped counter changed during frame")
            # FRG status bits are frame-scoped. Until its ID advances, even
            # overflow/busy/done describe the previous frame and are stale.
            if frg_id == frame_id:
                if frg_state & 0x2:
                    raise RuntimeError("FRG overflow")
                if not (frg_state & 0x4) and frg_state & 1:
                    if status & (1 << 3) and captured_id == frame_id:
                        return
            if time.monotonic() >= deadline:
                raise TimeoutError("FRG or preview capture completion timed out")
            time.sleep(min(0.001, max(0.0001, self.timeout_s / 100)))

    def transfer(self, jpeg: Any, frame_id: int, *, params_version: int = 0,
                 roi: tuple[int, int, int, int] = (0, 0, WIDTH, HEIGHT),
                 threshold: int = 128, intensity_offset: int = 0,
                 morph_mode: int = 0, auto_accept: bool = True):
        if self._closed:
            raise RuntimeError("JPEG transport is closed")
        if not isinstance(auto_accept, bool):
            raise TypeError("auto_accept must be bool")
        if self._pending_frame_id is not None:
            raise RuntimeError("previous completed frame has not been published")
        if self.dma_may_be_active:
            raise RuntimeError("DMA ownership uncertain; automatic retry is forbidden")
        frame_id = _uint(frame_id, "frame_id")
        if self._last_frame_id is not None and frame_id <= self._last_frame_id:
            raise ValueError("frame IDs must strictly increase")
        params_version = _uint(params_version, "params_version")
        view = _bytes_view(jpeg)
        length = view.nbytes
        if not length or length > JPEG_MAX_BYTES:
            raise ValueError("JPEG size must be in 1..512000 bytes")
        if length < 4 or bytes(view[:2]) != b"\xff\xd8" or bytes(view[-2:]) != b"\xff\xd9":
            raise ValueError("JPEG must have SOI and EOI markers")
        if (len(roi) != 4 or any(isinstance(v, bool) or not isinstance(v, numbers.Integral) for v in roi)
                or not (0 <= roi[0] < roi[2] <= WIDTH and 0 <= roi[1] < roi[3] <= HEIGHT)):
            raise ValueError("roi must be a valid nonempty rectangle in the 640x400 frame")
        threshold = _uint(threshold, "threshold", 255)
        if isinstance(intensity_offset, bool) or not isinstance(intensity_offset, numbers.Integral):
            raise TypeError("intensity_offset must be an integer")
        intensity_offset = int(intensity_offset)
        if not -255 <= intensity_offset <= 255:
            raise ValueError("intensity_offset must be in -255..255")
        morph_mode = _uint(morph_mode, "morph_mode", 2)
        self._preflight()
        self.tx_buffer[:length] = view
        sync_tx = getattr(self.tx_buffer, "sync_to_device", None)
        if not callable(sync_tx):
            raise RuntimeError("TX buffer has no sync_to_device method")
        sync_tx()
        # Snapshot drop count and clear any stale HLS valid indication before start.
        dropped_before = int(self.preview_control.read(0x0214))
        self.jpeg_control.read(JPEG_STATUS_VALID)
        self.jpeg_control.write(JPEG_SIZE, length)
        self.jpeg_control.write(JPEG_FRAME_ID, frame_id)
        if int(self.jpeg_control.read(JPEG_SIZE)) != length or int(self.jpeg_control.read(JPEG_FRAME_ID)) != frame_id:
            raise RuntimeError("JPEG size/frame ID readback mismatch")
        rle_values = {
            0x10: frame_id, 0x14: params_version,
            0x18: (roi[1] << 16) | roi[0], 0x1C: (roi[3] << 16) | roi[2],
            0x20: threshold, 0x24: intensity_offset & 0xFFFFFFFF, 0x28: morph_mode,
        }
        for offset, value in rle_values.items(): self.rle_control.write(offset, value)
        for offset, value in rle_values.items():
            if (int(self.rle_control.read(offset)) & 0xFFFFFFFF) != value:
                raise RuntimeError(f"RLE configuration readback mismatch at 0x{offset:02x}")
        # Mark ownership uncertain before the first operation that can arm/start DMA.
        # Once this point is reached, a start may occur; never reuse this ID even
        # if arming or any subsequent hardware transaction fails.
        self._last_frame_id = frame_id
        self.dma_may_be_active = True
        self.recv_channel.transfer(self.rx_buffer, nbytes=RX_CAPACITY)
        self.rle_control.write(0x00, 1)
        self.jpeg_control.write(JPEG_AP_CTRL, 1)
        self.send_channel.transfer(self.tx_buffer, nbytes=length)
        dma_bytes, rle_bytes = self._wait_for_completion()
        if dma_bytes != rle_bytes:
            raise RuntimeError("RLE and S2MM actual lengths disagree")
        if not 32 * 4 <= dma_bytes <= RX_CAPACITY or dma_bytes % 4:
            raise RuntimeError("RLE packet length is invalid")
        self.send_channel.wait()
        self.recv_channel.wait()
        self.dma_may_be_active = False
        self._completed_frames += 1
        sync_rx = getattr(self.rx_buffer, "sync_from_device", None)
        if not callable(sync_rx):
            raise RuntimeError("RX buffer has no sync_from_device method")
        sync_rx()
        jpeg_status = int(self.jpeg_control.read(JPEG_STATUS)) & 0xFFFFFFFF
        if jpeg_status:
            raise RuntimeError(f"JPEG status error: 0x{jpeg_status:08x}")
        packet = memoryview(self.rx_buffer).cast("B")[:dma_bytes]
        frame = decode_packet(packet, expected_frame_id=frame_id,
                              expected_params_version=params_version)
        if not frame.valid or frame.status != 0:
            raise RuntimeError("RLE packet status is nonzero or invalid")
        if (frame.roi != tuple(roi) or frame.threshold != threshold or
                frame.intensity_offset != intensity_offset or frame.morph_mode != morph_mode):
            raise ValueError("RLE packet parameters do not match request")
        self._wait_preview(frame_id, dropped_before)
        self._pending_frame_id = frame_id
        if auto_accept:
            self.accept_mask(frame_id)
        return frame

    def accept_mask(self, frame_id: int) -> None:
        """Publish the already validated mask after its matching metadata is ready."""
        frame_id = _uint(frame_id, "frame_id")
        if self._closed or self.dma_may_be_active:
            raise RuntimeError("cannot publish while transport is closed or DMA ownership is active")
        if self._pending_frame_id != frame_id:
            raise ValueError("mask acceptance does not match the pending completed frame")
        self.preview_control.write(PREVIEW_ACCEPT_ID, frame_id)
        self.preview_control.write(PREVIEW_MASK_ACCEPT, 1)
        deadline = time.monotonic() + self.timeout_s
        while True:
            status = int(self.preview_control.read(PREVIEW_STATUS))
            displayed_id = int(self.preview_control.read(PREVIEW_DISPLAYED_ID))
            if status & (1 << 4) and displayed_id == frame_id:
                self._pending_frame_id = None
                return
            if time.monotonic() >= deadline:
                raise TimeoutError("preview mask display timed out")
            time.sleep(min(0.001, max(0.0001, self.timeout_s / 100)))

    def publish_overlay(self, frame_id: int, total_count: int, boxes: Any, *,
                        line_x: int, enabled: bool = True) -> None:
        """Commit count, line and boxes for the pending frame before mask accept."""
        frame_id = _uint(frame_id, "frame_id")
        total_count = _uint(total_count, "total_count")
        line_x = _uint(line_x, "line_x")
        if line_x >= WIDTH:
            raise ValueError("line_x is outside the source image")
        if not isinstance(enabled, bool):
            raise TypeError("enabled must be bool")
        if self._closed or self.dma_may_be_active:
            raise RuntimeError("cannot configure overlay while transport is closed or DMA ownership is active")
        if self._pending_frame_id != frame_id:
            raise ValueError("overlay configuration does not match the pending completed frame")
        boxes = list(boxes)
        if len(boxes) > 16:
            raise ValueError("at most 16 overlay boxes are supported")
        checked = []
        for box in boxes:
            if not isinstance(box, (tuple, list)) or len(box) != 4:
                raise ValueError("each box must be (x0, y0, x1, y1)")
            x0, y0, x1, y1 = (_uint(v, "box coordinate") for v in box)
            if not (x0 <= x1 < WIDTH and y0 <= y1 < HEIGHT):
                raise ValueError("overlay box is outside the source image")
            checked.append((x0, y0, x1, y1))

        deadline = time.monotonic() + self.timeout_s
        while not (int(self.preview_control.read(PREVIEW_STATUS)) & 1):
            if time.monotonic() >= deadline:
                raise TimeoutError("overlay configuration mailbox did not become ready")
            time.sleep(min(0.001, max(0.0001, self.timeout_s / 100)))

        values = ((0x30, int(enabled)), (0x34, frame_id), (0x38, len(checked)),
                  (0x3C, line_x), (0x44, total_count))
        for offset, value in values:
            self.preview_control.write(offset, value)
        for offset, value in values:
            if (int(self.preview_control.read(offset)) & 0xFFFFFFFF) != value:
                raise RuntimeError(f"overlay configuration readback mismatch at 0x{offset:02x}")
        for index, (x0, y0, x1, y1) in enumerate(checked):
            x_word, y_word = x0 | (x1 << 16), y0 | (y1 << 16)
            self.preview_control.write(0x100 + 8 * index, x_word)
            self.preview_control.write(0x104 + 8 * index, y_word)
            if (int(self.preview_control.read(0x100 + 8 * index)) != x_word or
                    int(self.preview_control.read(0x104 + 8 * index)) != y_word):
                raise RuntimeError(f"overlay box {index} readback mismatch")
        self.preview_control.write(0x40, 1)

        # cfg_ready only rises again after the complete mailbox payload has
        # crossed into pixel_clk and has been latched at a VSYNC boundary.
        while not (int(self.preview_control.read(PREVIEW_STATUS)) & 1):
            if time.monotonic() >= deadline:
                raise TimeoutError("overlay configuration commit timed out")
            time.sleep(min(0.001, max(0.0001, self.timeout_s / 100)))
        self.accept_mask(frame_id)

    def close(self) -> None:
        if self._closed: return
        if self.dma_may_be_active:
            raise RuntimeError("DMA-owned buffers cannot be freed while ownership is uncertain")
        for channel, offset, name in (
                (self.send_channel, DMA_MM2S_STATUS, "MM2S"),
                (self.recv_channel, DMA_S2MM_STATUS, "S2MM")):
            stop = getattr(channel, "stop", None)
            if callable(stop):
                stop()
            status = int(self.dma_regs.read(offset))
            if status & DMA_STATUS_ERROR_MASK or not status & (DMA_IDLE | DMA_HALTED):
                raise RuntimeError(f"{name} DMA did not reach idle/halted state during close")
        for buffer in (self.tx_buffer, self.rx_buffer):
            free = getattr(buffer, "freebuffer", None)
            if not callable(free): raise RuntimeError("DMA buffer has no freebuffer method")
            free()
        self._closed = True
