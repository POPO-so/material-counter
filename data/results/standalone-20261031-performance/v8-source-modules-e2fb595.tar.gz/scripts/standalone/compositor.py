"""Fixed-geometry Gray8 display composition for the standalone G1 path."""

from __future__ import annotations

import binascii
import math
from time import perf_counter_ns
import uuid
from collections import OrderedDict
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


WIDTH = 1280
HEIGHT = 720
SOURCE_WIDTH = 640
SOURCE_HEIGHT = 400
VIEW_WIDTH = 576
VIEW_HEIGHT = 360
VIEW_X = 32
TOP_Y = 0
BOTTOM_Y = 360
MARKER_X = 640
MARKER_WIDTH = 224
UINT64_MAX = (1 << 64) - 1


def encode_marker(session_id: uuid.UUID, frame_id: int) -> bytes:
    """Encode the 224-bit MSB-first frame marker, including CCITT-FALSE CRC."""
    if not isinstance(session_id, uuid.UUID):
        raise TypeError("session_id must be uuid.UUID")
    if isinstance(frame_id, bool) or not isinstance(frame_id, (int, np.integer)):
        raise TypeError("frame_id must be an unsigned 64-bit integer")
    frame_value = int(frame_id)
    if not 0 <= frame_value <= UINT64_MAX:
        raise ValueError("frame_id is outside uint64 range")
    payload = b"MC" + session_id.bytes + frame_value.to_bytes(8, "big")
    return payload + binascii.crc_hqx(payload, 0xFFFF).to_bytes(2, "big")


def _integer(value, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise TypeError(f"{name} must be an integer")
    return int(value)


def _scale_coordinate(value: int) -> int:
    return math.floor(0.9 * value + 0.5)


class GrayComposer:
    """Reuse one Gray8 canvas and two scaled work areas for each display frame."""

    def __init__(self, font_path: str | Path, *, latin_font_path=None,
                 gray_interpolation=cv2.INTER_AREA):
        if (isinstance(gray_interpolation, bool) or not isinstance(gray_interpolation, int)
                or gray_interpolation not in (cv2.INTER_AREA, cv2.INTER_LINEAR)):
            raise ValueError("gray_interpolation must be INTER_AREA or INTER_LINEAR")
        self.canvas = np.zeros((HEIGHT, WIDTH), dtype=np.uint8)
        self.gray_interpolation = gray_interpolation
        self._gray_work = np.empty((VIEW_HEIGHT, VIEW_WIDTH), dtype=np.uint8)
        self._binary_work = np.empty((VIEW_HEIGHT, VIEW_WIDTH), dtype=np.uint8)
        self._font = ImageFont.truetype(str(font_path), 32)
        self._small_font = ImageFont.truetype(str(font_path), 24)
        self._small_latin_font = ImageFont.truetype(str(latin_font_path or font_path), 24)
        self._panel_image = Image.new("L", (WIDTH - 640, HEIGHT), 16)
        self._panel_draw = ImageDraw.Draw(self._panel_image)
        self._status_key = None
        self._glyph_cache = OrderedDict()
        self._status_glyphs = []
        self.panel_redraws = 0
        self.last_timings_ms = {"scale_ms": 0.0, "draw_ms": 0.0}
        self._canvas_panel_stale = False
        self._panel_draw.text((24, 22), "运行状态", font=self._font, fill=255)
        for index, value in enumerate((0, 128, 255)):
            x = 24 + index * 180
            self._panel_draw.rectangle((x, 70, x + 95, 98), fill=value)
            self._panel_draw.text((x + 104, 73), str(value), font=self._small_latin_font, fill=255)
        self._panel_base = self._panel_image.copy()
        np.copyto(self.canvas[:, 640:], np.asarray(self._panel_base))
        self._redraw_panel(())

    def _glyph(self, ch):
        """Keep font measurement and rasterization off recurring status updates."""
        cached = self._glyph_cache.get(ch)
        if cached is not None:
            self._glyph_cache.move_to_end(ch)
            return cached
        font = self._small_latin_font if ord(ch) < 256 else self._small_font
        left, top, right, bottom = font.getbbox(ch)
        mask = Image.new("L", (right - left, bottom - top))
        if mask.width and mask.height:
            ImageDraw.Draw(mask).text((-left, -top), ch, font=font, fill=255)
        cached = (font.getlength(ch), left, top, mask)
        self._glyph_cache[ch] = cached
        if len(self._glyph_cache) > 256:
            self._glyph_cache.popitem(last=False)
        return cached

    def _layout_status(self, status_lines):
        glyphs = []
        y = 126
        for line in status_lines:
            if y + 32 >= HEIGHT - 12:
                break
            x = 24.0
            for ch in line:
                advance, left, top, mask = self._glyph(ch)
                if x + advance > 616:
                    x, y = 24.0, y + 38
                if y + 32 >= HEIGHT - 12:
                    break
                if mask.width and mask.height:
                    glyphs.append((round(x) + left, y + top, ch, mask))
                x += advance
            y += 38
        return glyphs

    def _redraw_panel(self, status_lines: tuple[str, ...]) -> None:
        glyphs = self._layout_status(status_lines)
        previous = self._status_glyphs
        shared = 0
        # The unchanged prefix needs no repaint. Include both removed and added
        # suffixes so shortened or differently wrapped text leaves no old pixels.
        while (shared < min(len(previous), len(glyphs))
               and previous[shared][:3] == glyphs[shared][:3]):
            shared += 1
        changed = previous[shared:] + glyphs[shared:]
        if changed:
            x0 = max(0, min(x for x, y, ch, mask in changed))
            y0 = max(0, min(y for x, y, ch, mask in changed))
            x1 = min(WIDTH - 640, max(x + mask.width for x, y, ch, mask in changed))
            y1 = min(HEIGHT, max(y + mask.height for x, y, ch, mask in changed))
            if x0 < x1 and y0 < y1:
                dirty = (x0, y0, x1, y1)
                self._panel_image.paste(self._panel_base.crop(dirty), (x0, y0))
                # Redraw any retained glyph overlapping the dirty area, too.
                # Clip masks to avoid blending unchanged antialiased edges twice.
                for x, y, ch, mask in glyphs:
                    left, top = max(x, x0), max(y, y0)
                    right, bottom = min(x + mask.width, x1), min(y + mask.height, y1)
                    if left < right and top < bottom:
                        clipped = mask.crop((left - x, top - y, right - x, bottom - y))
                        self._panel_image.paste(255, (left, top, right, bottom), clipped)
                np.copyto(self.canvas[y0:y1, 640+x0:640+x1],
                          np.asarray(self._panel_image.crop(dirty)))
        self._status_glyphs = glyphs
        self._status_key = status_lines
        self.panel_redraws += 1

    @staticmethod
    def _validate_image(image, name: str) -> None:
        if not isinstance(image, np.ndarray):
            raise TypeError(f"{name} must be a numpy.ndarray")
        if image.shape != (SOURCE_HEIGHT, SOURCE_WIDTH):
            raise ValueError(f"{name} must have shape (400, 640)")
        if image.dtype != np.uint8:
            raise TypeError(f"{name} must have dtype uint8")

    def _validate_annotations(self, boxes, tracks, line_x, status_lines):
        try:
            box_items = tuple(boxes)
            track_items = tuple(tracks)
            status_items = tuple(status_lines)
        except TypeError as exc:
            raise TypeError("boxes, tracks, and status_lines must be iterable") from exc
        normalized_boxes = []
        for box in box_items:
            if len(box) != 4:
                raise ValueError("each box must be (x1, y1, x2, y2)")
            x1, y1, x2, y2 = (_integer(value, "box coordinate") for value in box)
            if x2 < x1 or y2 < y1:
                raise ValueError("box end coordinates must not precede start coordinates")
            normalized_boxes.append((x1, y1, x2, y2))

        normalized_tracks = []
        for track in track_items:
            if len(track) != 3:
                raise ValueError("each track must be (track_id, x, y)")
            track_id, x, y = track
            text = str(track_id)
            if not text.isascii():
                raise ValueError("track IDs must be ASCII")
            normalized_tracks.append((text, _integer(x, "track x"), _integer(y, "track y")))

        if any(not isinstance(line, str) for line in status_items):
            raise TypeError("status_lines must contain strings")
        normalized_status = tuple(status_items)
        return normalized_boxes, normalized_tracks, _integer(line_x, "line_x"), normalized_status

    def _draw_overlays(self, boxes, tracks, line_x: int, line_y=None) -> None:
        image = self.canvas[BOTTOM_Y:HEIGHT, VIEW_X:VIEW_X + VIEW_WIDTH]
        if line_y is None:
            x = _scale_coordinate(min(max(line_x, 0), SOURCE_WIDTH - 1))
            first, last = (x, 0), (x, VIEW_HEIGHT - 1)
        else:
            y = _scale_coordinate(min(max(line_y, 0), SOURCE_HEIGHT - 1))
            first, last = (0, y), (VIEW_WIDTH - 1, y)
        cv2.line(image, first, last, 0, 3, cv2.LINE_8)
        cv2.line(image, first, last, 255, 1, cv2.LINE_8)

        for x1, y1, x2, y2 in boxes:
            x1 = _scale_coordinate(min(max(x1, 0), SOURCE_WIDTH - 1))
            x2 = _scale_coordinate(min(max(x2, 0), SOURCE_WIDTH - 1))
            y1 = _scale_coordinate(min(max(y1, 0), SOURCE_HEIGHT - 1))
            y2 = _scale_coordinate(min(max(y2, 0), SOURCE_HEIGHT - 1))
            first = (x1, y1)
            last = (x2, y2)
            cv2.rectangle(image, first, last, 0, 4, cv2.LINE_8)
            cv2.rectangle(image, first, last, 255, 2, cv2.LINE_8)

        for track_id, source_x, source_y in tracks:
            x = _scale_coordinate(min(max(source_x, 0), SOURCE_WIDTH - 1))
            y = _scale_coordinate(min(max(source_y, 0), SOURCE_HEIGHT - 1))
            origin = (x, max(13, y - 4))
            cv2.putText(image, track_id, origin, cv2.FONT_HERSHEY_SIMPLEX, 0.45, 0, 3, cv2.LINE_8)
            cv2.putText(image, track_id, origin, cv2.FONT_HERSHEY_SIMPLEX, 0.45, 255, 1, cv2.LINE_8)

    def _write_markers(self, marker: bytes) -> None:
        bits = np.unpackbits(np.frombuffer(marker, dtype=np.uint8), bitorder="big")
        pixels = bits * np.uint8(255)
        self.canvas[TOP_Y, MARKER_X:MARKER_X + MARKER_WIDTH] = pixels
        self.canvas[HEIGHT - 1, MARKER_X:MARKER_X + MARKER_WIDTH] = pixels

    def render(
        self,
        gray,
        binary,
        session_id: uuid.UUID,
        frame_id: int,
        boxes=(),
        tracks=(),
        line_x=320,
        status_lines=(),
        *,
        binary_background: bool = True,
        output=None,
        line_y=None,
    ) -> np.ndarray:
        """Render a same-identity gray/binary pair into the reusable canvas or output."""
        if not isinstance(binary_background, bool):
            raise TypeError("binary_background must be bool")
        if output is not None and (
            not isinstance(output, np.ndarray)
            or output.shape != (HEIGHT, WIDTH)
            or output.dtype != np.uint8
            or not output.flags.writeable
            or not output.flags.c_contiguous
        ):
            raise TypeError("output must be a writable C-contiguous (720,1280) uint8 array")
        self._validate_image(gray, "gray")
        self._validate_image(binary, "binary")
        if not np.all((binary == 0) | (binary == 255)):
            raise ValueError("binary input may contain only 0 and 255")
        marker = encode_marker(session_id, frame_id)
        normalized_boxes, normalized_tracks, normalized_line, normalized_status = self._validate_annotations(
            boxes, tracks, line_x, status_lines
        )

        if line_y is not None:
            line_y = _integer(line_y, "line_y")
        reusable_canvas = self.canvas
        if output is not None:
            self.canvas = output
        try:
            self.canvas[:VIEW_HEIGHT, :SOURCE_WIDTH].fill(0)
            self.canvas[BOTTOM_Y:HEIGHT, :SOURCE_WIDTH].fill(0)
            scale_start_ns = perf_counter_ns()
            cv2.resize(gray, (VIEW_WIDTH, VIEW_HEIGHT), dst=self._gray_work,
                       interpolation=self.gray_interpolation)
            self.canvas[TOP_Y:TOP_Y + VIEW_HEIGHT, VIEW_X:VIEW_X + VIEW_WIDTH] = self._gray_work
            if binary_background:
                cv2.resize(binary, (VIEW_WIDTH, VIEW_HEIGHT), dst=self._binary_work, interpolation=cv2.INTER_NEAREST)
                self.canvas[BOTTOM_Y: BOTTOM_Y + VIEW_HEIGHT,
                            VIEW_X: VIEW_X + VIEW_WIDTH] = self._binary_work
            else:
                self.canvas[BOTTOM_Y: BOTTOM_Y + VIEW_HEIGHT,
                            VIEW_X: VIEW_X + VIEW_WIDTH] = self._gray_work
            scale_ms = (perf_counter_ns() - scale_start_ns) / 1_000_000

            draw_start_ns = perf_counter_ns()
            self._draw_overlays(normalized_boxes, normalized_tracks, normalized_line, line_y)

            if normalized_status != self._status_key:
                self._redraw_panel(normalized_status)
            if output is not None:
                np.copyto(self.canvas[:, SOURCE_WIDTH:], np.asarray(self._panel_image))
            elif self._canvas_panel_stale:
                np.copyto(self.canvas[:, SOURCE_WIDTH:], np.asarray(self._panel_image))
                self._canvas_panel_stale = False
            self._write_markers(marker)
            draw_ms = (perf_counter_ns() - draw_start_ns) / 1_000_000
            self.last_timings_ms = {"scale_ms": scale_ms, "draw_ms": draw_ms}
            return self.canvas
        finally:
            if output is not None:
                if output is not reusable_canvas:
                    self._canvas_panel_stale = True
                self.canvas = reusable_canvas


class DashboardComposer:
    """Gray8 operator dashboard with an undistorted 640x400 camera viewport.

    The diagnostic composer above remains available to the G1/G2 tools. Both
    layouts retain the same top/bottom session markers for the PL observer.
    """

    VIEW = (256, 144, 768, 480)

    def __init__(self, font_path, *, latin_font_path=None,
                 gray_interpolation=cv2.INTER_AREA):
        if gray_interpolation not in (cv2.INTER_AREA, cv2.INTER_LINEAR):
            raise ValueError("gray_interpolation must be INTER_AREA or INTER_LINEAR")
        self.gray_interpolation = gray_interpolation
        self.canvas = np.zeros((HEIGHT, WIDTH), dtype=np.uint8)
        self._work = np.empty((480, 768), dtype=np.uint8)
        self._fonts = {size: ImageFont.truetype(str(font_path), size)
                       for size in (18, 20, 24, 34)}
        self._latin = {size: ImageFont.truetype(str(latin_font_path or font_path), size)
                       for size in (18, 20, 24, 28, 34)}
        self._text_cache = OrderedDict()
        self._key = None
        self._chrome = np.zeros_like(self.canvas)
        self.last_timings_ms = {"scale_ms": 0.0, "draw_ms": 0.0}

    @staticmethod
    def _number(value, digits=1, suffix=""):
        if (isinstance(value, bool) or not isinstance(value, (int, float))
                or not math.isfinite(value) or value < 0):
            return "--"
        return f"{value:,.{digits}f}{suffix}"

    def _text(self, draw, xy, text, size, fill):
        key = ("mixed", text, size)
        cached = self._text_cache.get(key)
        if cached is None:
            # Render at an integer offset so glyph bearings and fractional
            # advances match the original per-character drawing path exactly.
            margin = 64
            width = margin * 2 + sum(
                (self._latin[size] if ord(character) < 256 else self._fonts[size])
                .getlength(character) for character in text)
            mask = Image.new("L", (max(1, math.ceil(width)), size * 4 + margin * 2), 0)
            mask_draw = ImageDraw.Draw(mask)
            x = float(margin)
            for character in text:
                font = self._latin[size] if ord(character) < 256 else self._fonts[size]
                mask_draw.text((x, margin + size), character, font=font,
                               fill=255, anchor="ls")
                x += font.getlength(character)
            bounds = mask.getbbox()
            if bounds is None:
                cached = (0, 0, mask.crop((0, 0, 1, 1)))
            else:
                left, top, right, bottom = bounds
                cached = (left - margin, top - margin,
                          mask.crop((left, top, right, bottom)))
        else:
            self._text_cache.move_to_end(key)
        self._cache_text(key, cached)
        offset_x, offset_y, mask = cached
        draw.bitmap((xy[0] + offset_x, xy[1] + offset_y), mask, fill=fill)

    def _cache_text(self, key, cached):
        self._text_cache[key] = cached
        if len(self._text_cache) > 128:
            self._text_cache.popitem(last=False)

    def _whole_latin_text(self, draw, xy, text, size, fill):
        """Draw cached complete Latin strings with Pillow's default text layout."""
        key = ("latin", text, size)
        cached = self._text_cache.get(key)
        if cached is None:
            font = self._latin[size]
            left, top, right, bottom = font.getbbox(text)
            mask = Image.new("L", (max(1, right - left), max(1, bottom - top)), 0)
            ImageDraw.Draw(mask).text((-left, -top), text, font=font, fill=255)
            cached = (left, top, mask)
        else:
            self._text_cache.move_to_end(key)
        self._cache_text(key, cached)
        offset_x, offset_y, mask = cached
        draw.bitmap((xy[0] + offset_x, xy[1] + offset_y), mask, fill=fill)

    def _redraw_chrome(self, dashboard, binary_background, target_count, lines):
        values = (
            self._number(dashboard.get("count"), 0),
            self._number(dashboard.get("display_fps")),
            self._number(dashboard.get("processing_ms"), 1, " ms"),
            self._number(dashboard.get("cpu_percent"), 0, "%"),
            self._number(dashboard.get("memory_percent"), 0, "%"),
        )
        state = str(dashboard.get("state", "RUNNING"))
        detail = tuple(lines[:3]) if dashboard.get("detail_page") else ()
        key = (values, state, binary_background, target_count, detail)
        if key == self._key:
            return
        image = Image.new("L", (WIDTH, HEIGHT), 14)
        draw = ImageDraw.Draw(image)
        self._whole_latin_text(draw, (24, 12), "NUT VISION COUNTER", 28, 242)
        draw.ellipse((1060, 25, 1070, 35), fill=224)
        self._whole_latin_text(draw, (1082, 19), state[:15], 18, 208)
        for x, label, value in zip((24, 440, 856),
                                   ("本次累计计数", "显示 FPS", "处理延迟 / RLE + 计数"),
                                   values[:3]):
            draw.rounded_rectangle((x, 58, x + 400, 126), radius=10, fill=42)
            self._text(draw, (x + 16, 62), label, 18, 170)
            self._whole_latin_text(draw, (x + 16, 84), value, 34, 248)
        draw.rounded_rectangle((24, 136, 1256, 632), radius=10, fill=25, outline=58)
        self._whole_latin_text(draw, (42, 157), "CAM 01", 24, 232)
        self._whole_latin_text(draw, (42, 194), "640 x 400", 18, 158)
        self._text(draw, (42, 222), "二值预览" if binary_background else "实时灰度画面", 20, 212)
        draw.line((44, 284, 100, 284), fill=240, width=2)
        self._text(draw, (42, 298), "实际计数线", 18, 175)
        self._text(draw, (42, 328), "从左向右计数", 18, 212)
        for y, text in zip((448, 480, 512, 544),
                           ("BTN0  暂停 / 恢复", "BTN1  长按 2 秒清零",
                            "BTN2  灰度 / 二值", "BTN3  详细状态")):
            self._text(draw, (42, y), text, 18, 144)
        self._text(draw, (1044, 158), "检测目标", 20, 170)
        self._whole_latin_text(draw, (1044, 190), str(target_count), 34, 242)
        self._text(draw, (1044, 248), "跟踪 ID / 检测框", 18, 170)
        self._text(draw, (1044, 279), "计数真值待人工核对", 18, 144)
        for i, text in enumerate(detail):
            # Keep diagnostic text inside the narrow gutter.
            for row in range(0, min(len(text), 30), 10):
                self._text(draw, (1044, 344 + i * 78 + row // 10 * 24), text[row:row + 10], 18, 170)
        for x, width, label, text, field in (
                (24, 600, "PS CPU 使用率", values[3], "cpu_percent"),
                (640, 616, "DDR 内存占用", values[4], "memory_percent")):
            draw.rounded_rectangle((x, 646, x + width, 704), radius=9, fill=40)
            self._text(draw, (x + 16, 650), label, 18, 178)
            self._whole_latin_text(draw, (x + width - 74, 674), text, 18, 238)
            left, right = x + 16, x + width - 92
            draw.rounded_rectangle((left, 682, right, 689), radius=3, fill=82)
            percent = dashboard.get(field)
            if (isinstance(percent, (int, float)) and not isinstance(percent, bool)
                    and math.isfinite(percent) and percent > 0):
                end = left + round((right - left) * min(100, percent) / 100)
                if end > left:
                    draw.rounded_rectangle((left, 682, end, 689), radius=3, fill=218)
        self._chrome[:] = np.asarray(image)
        self._key = key

    def render(self, gray, binary, session_id, frame_id, boxes=(), tracks=(),
               line_x=320, status_lines=(), *, binary_background=False, output=None,
               line_y=None, dashboard=None):
        GrayComposer._validate_image(gray, "gray")
        GrayComposer._validate_image(binary, "binary")
        if not isinstance(binary_background, bool):
            raise TypeError("binary_background must be bool")
        if binary_background and not np.all((binary == 0) | (binary == 255)):
            raise ValueError("binary input may contain only 0 and 255")
        target = self.canvas if output is None else output
        if (not isinstance(target, np.ndarray) or target.shape != (HEIGHT, WIDTH)
                or target.dtype != np.uint8 or not target.flags.c_contiguous
                or not target.flags.writeable):
            raise TypeError("output must be a writable C-contiguous (720,1280) uint8 array")
        boxes, tracks, line_x, lines = GrayComposer._validate_annotations(
            self, boxes, tracks, line_x, status_lines)
        if line_y is not None:
            line_y = _integer(line_y, "line_y")
        marker = encode_marker(session_id, frame_id)
        started = perf_counter_ns()
        self._redraw_chrome(dict(dashboard or {}), binary_background, len(boxes), lines)
        np.copyto(target, self._chrome)
        draw_ms = (perf_counter_ns() - started) / 1_000_000
        started = perf_counter_ns()
        cv2.resize(binary if binary_background else gray, (768, 480), dst=self._work,
                   interpolation=cv2.INTER_NEAREST if binary_background else self.gray_interpolation)
        x0, y0, width, height = self.VIEW
        image = target[y0:y0 + height, x0:x0 + width]
        np.copyto(image, self._work)
        scale_ms = (perf_counter_ns() - started) / 1_000_000
        started = perf_counter_ns()
        sx = lambda x: min(width - 1, max(0, math.floor(x * width / SOURCE_WIDTH + 0.5)))
        sy = lambda y: min(height - 1, max(0, math.floor(y * height / SOURCE_HEIGHT + 0.5)))
        horizontal = line_y is not None
        fixed = sy(line_y) if horizontal else sx(line_x)
        extent = width if horizontal else height
        for start in range(0, extent, 24):
            end = min(extent - 1, start + 13)
            a, b = ((start, fixed), (end, fixed)) if horizontal else ((fixed, start), (fixed, end))
            cv2.line(image, a, b, 0, 5, cv2.LINE_8)
            cv2.line(image, a, b, 248, 2, cv2.LINE_8)
        label_at = (12, max(22, fixed - 12)) if horizontal else (min(width - 140, fixed + 12), 24)
        cv2.putText(image, "COUNT LINE", label_at, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 0, 4, cv2.LINE_8)
        cv2.putText(image, "COUNT LINE", label_at, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 248, 1, cv2.LINE_8)
        for x1, y1, x2, y2 in boxes:
            a, b = (sx(x1), sy(y1)), (sx(x2), sy(y2))
            cv2.rectangle(image, a, b, 0, 5, cv2.LINE_8)
            cv2.rectangle(image, a, b, 245, 2, cv2.LINE_8)
        for track_id, x, y in tracks:
            origin = (min(width - 100, sx(x)), max(21, sy(y) - 10))
            cv2.putText(image, "ID " + track_id, origin, cv2.FONT_HERSHEY_SIMPLEX,
                        0.6, 0, 4, cv2.LINE_8)
            cv2.putText(image, "ID " + track_id, origin, cv2.FONT_HERSHEY_SIMPLEX,
                        0.6, 248, 1, cv2.LINE_8)
        bits = np.unpackbits(np.frombuffer(marker, dtype=np.uint8), bitorder="big") * np.uint8(255)
        target[0, MARKER_X:MARKER_X + MARKER_WIDTH] = bits
        target[HEIGHT - 1, MARKER_X:MARKER_X + MARKER_WIDTH] = bits
        self.last_timings_ms = {"scale_ms": scale_ms,
                                "draw_ms": draw_ms + (perf_counter_ns() - started) / 1_000_000}
        return target
